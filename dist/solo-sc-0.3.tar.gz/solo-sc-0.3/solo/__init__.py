__author__ = 'David Kelley, Nick Bernstein'
__email__ = 'nicholas@calicolabs.com'
__version__ = '0.1'

from . import hashsolo, utils
